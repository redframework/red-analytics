<p align="center"><a href="http://redframework.ir" target="_blank">
    <img src="http://redframework.ir/public/Red/Images/Red_Framework_Logo_For_Header.png">
</a></p>

[Red Framework Console Devlopment Kit][1] is **PHP Framework** Which Provides Command System and High-Quality Components to Develop Console App with **PHP** as Fast as Possible .

Installation
------------

* Install Red Framework Console Kit With [Red Analytics][2]
* Install Red Framework Console Kit With [Composer][3]
* Download Red Framework Console Kit From Our [Official Site][1]

Documentation
-------------

* Read the [Documentation][4] From Red Framework [Official Site][1].


About Us
--------

Red Framework development is Done with <3 By RedCoder (M.Azizkhani)

[1]: http://redframework.ir
[2]: http://redframework.ir/projects/red-analytics
[3]: https://packagist.org/packages/redframework/console-kit
[4]: http://redframework.ir/documentation/en/console-kit/master/document.html
