<p align="center"><a href="http://redframework.ir" target="_blank">
    <img src="http://redframework.ir/public/Red/Images/Red_Framework_Logo_For_Header.png">
</a></p>

[Red Framework Enterprise Kit][1] is a Modern **PHP MVC Framework** For Enterprise Web Applications Merged with **Special Tools and Components** to Speed up and Organize Development .

Installation
------------

* Install Red Framework Enterprise With [Red Analytics][2]
* Install Red Framework Enterprise With [Composer][3]
* Download Red Framework Enterprise From Our [Official Site][1]

Documentation
-------------

* Read the [Documentation][4] From Red Framework [Official Site][1].


About Us
--------

Red Framework development is Done with <3 By RedCoder (M.Azizkhani)

[1]: http://redframework.ir
[2]: http://redframework.ir/projects/red-analytics
[3]: https://packagist.org/packages/redframework/enterprise
[4]: http://redframework.ir/documentation/en/enterprise/master/document.html