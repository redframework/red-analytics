<?php
/** Red Framework
 * API Base Class
 *
 * Use 'APIService@method' in Route Action to Access Methods
 * @author RedCoder
 * http://redframework.ir
 */

namespace App\APIs;


class APIService
{
    public function API()
    {

    }

}